package com.example.pomodoro.viewmodels

import android.os.CountDownTimer
import androidx.lifecycle.ViewModel

class TimerViewModel(var timer: CountDownTimer, var studyLength: Long, var breakLength: Long, var isStudyTime: Boolean): ViewModel() {

}